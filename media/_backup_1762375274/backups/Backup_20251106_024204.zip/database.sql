-- PostgreSQL database dump created by Django backup system
-- Database: gisdb
-- Created: 2025-11-05T20:42:04.472083+00:00

-- Table: Login_backup
DROP TABLE IF EXISTS Login_backup CASCADE;
CREATE TABLE Login_backup (
    id bigint NOT NULL,
    name character varying NOT NULL,
    backup_type character varying NOT NULL,
    status character varying NOT NULL,
    file_path character varying,
    file_size bigint,
    created_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    error_message text,
    description text,
    created_by_id integer NOT NULL
);

-- Table: Login_backup (1 rows)
INSERT INTO "Login_backup" ("id", "name", "backup_type", "status", "file_path", "file_size", "created_at", "completed_at", "error_message", "description", "created_by_id") VALUES (6, 'Backup_20251106_024204', 'full', 'in_progress', NULL, NULL, '2025-11-06T02:42:04.415948+06:00', NULL, NULL, '', 6);

-- Table: Login_profile
DROP TABLE IF EXISTS Login_profile CASCADE;
CREATE TABLE Login_profile (
    id bigint NOT NULL,
    full_name character varying NOT NULL,
    phone character varying NOT NULL,
    email character varying NOT NULL,
    address text NOT NULL,
    profile_picture character varying NOT NULL,
    user_status character varying NOT NULL,
    user_id integer NOT NULL
);

-- Table: Login_profile (2 rows)
INSERT INTO "Login_profile" ("id", "full_name", "phone", "email", "address", "profile_picture", "user_status", "user_id") VALUES (5, 'admin', '', 'admin@test.com', '', '', 'user', 6);
INSERT INTO "Login_profile" ("id", "full_name", "phone", "email", "address", "profile_picture", "user_status", "user_id") VALUES (6, 'nasir', '', 'nasir@test.com', '', '', 'user', 8);

-- Table: Map_historicalmap
DROP TABLE IF EXISTS Map_historicalmap CASCADE;
CREATE TABLE Map_historicalmap (
    id bigint NOT NULL,
    title character varying NOT NULL,
    status character varying NOT NULL,
    thumbnail text NOT NULL,
    publishing_date timestamp with time zone NOT NULL,
    views_count integer NOT NULL,
    history_id integer NOT NULL,
    history_date timestamp with time zone NOT NULL,
    history_change_reason character varying,
    history_type character varying NOT NULL,
    history_user_id integer,
    user_id integer
);

-- Table: Map_map
DROP TABLE IF EXISTS Map_map CASCADE;
CREATE TABLE Map_map (
    id bigint NOT NULL,
    title character varying NOT NULL,
    status character varying NOT NULL,
    thumbnail character varying NOT NULL,
    publishing_date timestamp with time zone NOT NULL,
    views_count integer NOT NULL,
    user_id integer NOT NULL
);

-- Table: Map_mapcolor
DROP TABLE IF EXISTS Map_mapcolor CASCADE;
CREATE TABLE Map_mapcolor (
    id bigint NOT NULL,
    color character varying NOT NULL,
    map_id bigint NOT NULL
);

-- Table: Map_mapfile
DROP TABLE IF EXISTS Map_mapfile CASCADE;
CREATE TABLE Map_mapfile (
    id bigint NOT NULL,
    file character varying NOT NULL,
    map_id bigint NOT NULL
);

-- Table: auth_group
DROP TABLE IF EXISTS auth_group CASCADE;
CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying NOT NULL
);

-- Table: auth_group_permissions
DROP TABLE IF EXISTS auth_group_permissions CASCADE;
CREATE TABLE auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);

-- Table: auth_permission
DROP TABLE IF EXISTS auth_permission CASCADE;
CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying NOT NULL
);

-- Table: auth_user
DROP TABLE IF EXISTS auth_user CASCADE;
CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    email character varying NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);

-- Table: auth_user (2 rows)
INSERT INTO "auth_user" ("id", "password", "last_login", "is_superuser", "username", "first_name", "last_name", "email", "is_staff", "is_active", "date_joined") VALUES (6, 'pbkdf2_sha256$600000$bX15wz7Pay48kxDnvZImg6$024zOHeHIhX8oKfUodO9p3hr587fygepVqSKq0B6BXE=', '2025-11-06T02:37:59.707063+06:00', True, 'admin', '', '', 'admin@test.com', True, True, '2025-11-06T02:32:31.959458+06:00');
INSERT INTO "auth_user" ("id", "password", "last_login", "is_superuser", "username", "first_name", "last_name", "email", "is_staff", "is_active", "date_joined") VALUES (8, 'pbkdf2_sha256$600000$or5WWM5ZK4fozi6hnx6t81$MrE5mBzI0dXveWmANudbTMGqkhdnYKTWp4B8J/HM5Ms=', NULL, False, 'nasir', '', '', 'nasir@test.com', False, True, '2025-11-06T02:40:01.256775+06:00');

-- Table: auth_user_groups
DROP TABLE IF EXISTS auth_user_groups CASCADE;
CREATE TABLE auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);

-- Table: auth_user_user_permissions
DROP TABLE IF EXISTS auth_user_user_permissions CASCADE;
CREATE TABLE auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);

-- Table: django_admin_log
DROP TABLE IF EXISTS django_admin_log CASCADE;
CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL
);

-- Table: django_content_type
DROP TABLE IF EXISTS django_content_type CASCADE;
CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying NOT NULL,
    model character varying NOT NULL
);

-- Table: django_content_type (12 rows)
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (1, 'admin', 'logentry');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (2, 'auth', 'permission');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (3, 'auth', 'group');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (4, 'auth', 'user');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (5, 'contenttypes', 'contenttype');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (6, 'sessions', 'session');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (7, 'Map', 'map');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (8, 'Map', 'mapfile');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (9, 'Map', 'historicalmap');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (10, 'Map', 'mapcolor');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (11, 'Login', 'profile');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (12, 'Login', 'backup');

-- Table: django_migrations
DROP TABLE IF EXISTS django_migrations CASCADE;
CREATE TABLE django_migrations (
    id bigint NOT NULL,
    app character varying NOT NULL,
    name character varying NOT NULL,
    applied timestamp with time zone NOT NULL
);

-- Table: django_migrations (36 rows)
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (1, 'contenttypes', '0001_initial', '2025-11-06T02:02:48.274637+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (2, 'auth', '0001_initial', '2025-11-06T02:02:48.345368+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (3, 'Login', '0001_initial', '2025-11-06T02:02:48.362413+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (4, 'Login', '0002_alter_profile_user_status', '2025-11-06T02:02:48.368949+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (5, 'Login', '0003_alter_profile_profile_picture', '2025-11-06T02:02:48.374954+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (6, 'Login', '0004_backup', '2025-11-06T02:02:48.399952+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (7, 'Map', '0001_initial', '2025-11-06T02:02:48.494033+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (8, 'Map', '0002_alter_map_status', '2025-11-06T02:02:48.777388+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (9, 'Map', '0003_alter_map_thumbnail', '2025-11-06T02:02:48.921146+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (10, 'Map', '0004_historicalmap', '2025-11-06T02:02:48.944632+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (11, 'Map', '0005_notification', '2025-11-06T02:02:48.968869+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (12, 'Map', '0006_remove_notification_user_notification_recipient', '2025-11-06T02:02:49.000123+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (13, 'Map', '0007_alter_notification_recipient', '2025-11-06T02:02:49.014659+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (14, 'Map', '0008_delete_notification', '2025-11-06T02:02:49.018959+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (15, 'Map', '0009_mapcolor', '2025-11-06T02:02:49.039469+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (16, 'Map', '0010_alter_mapcolor_color', '2025-11-06T02:02:49.044976+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (17, 'Map', '0011_alter_mapcolor_color', '2025-11-06T02:02:49.050507+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (18, 'Map', '0012_alter_mapcolor_color', '2025-11-06T02:02:49.056037+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (19, 'Map', '0013_alter_map_options', '2025-11-06T02:02:49.065582+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (20, 'Map', '0014_alter_map_options', '2025-11-06T02:02:49.073048+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (21, 'admin', '0001_initial', '2025-11-06T02:02:49.093134+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (22, 'admin', '0002_logentry_remove_auto_add', '2025-11-06T02:02:49.101669+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (23, 'admin', '0003_logentry_add_action_flag_choices', '2025-11-06T02:02:49.111185+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (24, 'contenttypes', '0002_remove_content_type_name', '2025-11-06T02:02:49.126580+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (25, 'auth', '0002_alter_permission_name_max_length', '2025-11-06T02:02:49.137101+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (26, 'auth', '0003_alter_user_email_max_length', '2025-11-06T02:02:49.145651+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (27, 'auth', '0004_alter_user_username_opts', '2025-11-06T02:02:49.156984+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (28, 'auth', '0005_alter_user_last_login_null', '2025-11-06T02:02:49.205486+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (29, 'auth', '0006_require_contenttypes_0002', '2025-11-06T02:02:49.207964+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (30, 'auth', '0007_alter_validators_add_error_messages', '2025-11-06T02:02:49.216128+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (31, 'auth', '0008_alter_user_username_max_length', '2025-11-06T02:02:49.228664+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (32, 'auth', '0009_alter_user_last_name_max_length', '2025-11-06T02:02:49.237136+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (33, 'auth', '0010_alter_group_name_max_length', '2025-11-06T02:02:49.248187+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (34, 'auth', '0011_update_proxy_permissions', '2025-11-06T02:02:49.258730+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (35, 'auth', '0012_alter_user_first_name_max_length', '2025-11-06T02:02:49.268015+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (36, 'sessions', '0001_initial', '2025-11-06T02:02:49.276584+06:00');

-- Table: django_session
DROP TABLE IF EXISTS django_session CASCADE;
CREATE TABLE django_session (
    session_key character varying NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);

-- Table: django_session (5 rows)
INSERT INTO "django_session" ("session_key", "session_data", "expire_date") VALUES ('d9rhjm9zlp9whari84egx6xi9rbdtsfj', '.eJxVjLkOwjAQRP_FNYps42spkehAVNTW2rsmETmkmFSIfydIKaCcN2_mJSIuzzYulefYkTgIJXa_LGF-8PgtztO9G5st1-Y0YNdf59sqjTjwZSLuj5v899Bibdd5QCWdRSgewPnEBY0mixqAig_EIYBWxmWQ0tugqICz7BmYHGST9uL9ARnZOB8:1vGjnc:f2o9_Bj83bZlqIgJJm27gL-_U1J-V0pDYnjx0hyesZs', '2025-11-20T02:08:08.160521+06:00');
INSERT INTO "django_session" ("session_key", "session_data", "expire_date") VALUES ('fhb66392w025zj1zngxonht2dq5clb5z', '.eJxVjLkOwjAQRP_FNYps42spkehAVNTW2rsmETmkmFSIfydIKaCcN2_mJSIuzzYulefYkTgIJXa_LGF-8PgtztO9G5st1-Y0YNdf59sqjTjwZSLuj5v899Bibdd5QCWdRSgewPnEBY0mixqAig_EIYBWxmWQ0tugqICz7BmYHGST9uL9ARnZOB8:1vGjoA:S20lOHUwDHoSOchTnE9nkZsy1VFLz43QnPk9908zHh0', '2025-11-20T02:08:42.510765+06:00');
INSERT INTO "django_session" ("session_key", "session_data", "expire_date") VALUES ('zq54yrptaiuegd7af2xglkic95idysgk', '.eJxVjLkOwjAQRP_FNYps42spkehAVNTW2rsmETmkmFSIfydIKaCcN2_mJSIuzzYulefYkTgIJXa_LGF-8PgtztO9G5st1-Y0YNdf59sqjTjwZSLuj5v899Bibdd5QCWdRSgewPnEBY0mixqAig_EIYBWxmWQ0tugqICz7BmYHGST9uL9ARnZOB8:1vGjpp:L7aDyDCxejcPD4S8uLuFytzjDfdD7OOOxO_HgpXFudE', '2025-11-20T02:10:25.325222+06:00');
INSERT INTO "django_session" ("session_key", "session_data", "expire_date") VALUES ('thy9o5ug4m784360pd5u2stt8j9ttdu5', '.eJxVjLkOwjAQRP_FNYps42spkehAVNTW2rsmETmkmFSIfydIKaCcN2_mJSIuzzYulefYkTgIJXa_LGF-8PgtztO9G5st1-Y0YNdf59sqjTjwZSLuj5v899Bibdd5QCWdRSgewPnEBY0mixqAig_EIYBWxmWQ0tugqICz7BmYHGST9uL9ARnZOB8:1vGjsh:uK4LfWllTevbAfiJfKA4AMqxgxl517qp0NFHBSGZk-g', '2025-11-20T02:13:23.837923+06:00');
INSERT INTO "django_session" ("session_key", "session_data", "expire_date") VALUES ('z8i7ftcawiwjomn2n5tlssiu7okir42j', '.eJxVjLEOwiAURf-F2TQFCgVHk24aJ2fyeDyE2NKk2Mn479akg4733HPvizlYn8mtlRaXAzsyzQ6_zAM-qHyL83zPpdlzbYYJ8nhdbptUYKLLHGg87fLfQ4KatrnQbWwBhCFuPBntFQUpdcSO-h6lEUjcRiF6i9r7jkNAaVuLKir0Fom9PzOkOQ8:1vGkGW:qsGnjjZfQnCOLfiLuyk8tj38172KLzsu3FXJhIn-H1I', '2025-11-20T02:38:00.553228+06:00');

