-- PostgreSQL database dump created by Django backup system
-- Database: gisdb
-- Created: 2025-11-05T19:52:21.621780+00:00

-- Table: Login_backup
DROP TABLE IF EXISTS Login_backup CASCADE;
CREATE TABLE Login_backup (
    id bigint NOT NULL,
    name character varying NOT NULL,
    backup_type character varying NOT NULL,
    status character varying NOT NULL,
    file_path character varying,
    file_size bigint,
    created_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    error_message text,
    description text,
    created_by_id integer NOT NULL
);

-- Table: Login_backup (2 rows)
INSERT INTO "Login_backup" ("id", "name", "backup_type", "status", "file_path", "file_size", "created_at", "completed_at", "error_message", "description", "created_by_id") VALUES (1, 'Test_Restore_Fix_Backup', 'full', 'completed', 'C:\Users\aminu\Downloads\Compressed\GIS 1 june\myprojectdir\media\backups\Backup_20251106_002924.zip', NULL, '2025-11-06T01:44:43.057886+06:00', NULL, NULL, 'Test backup to test the restore auth_user fix', 1);
INSERT INTO "Login_backup" ("id", "name", "backup_type", "status", "file_path", "file_size", "created_at", "completed_at", "error_message", "description", "created_by_id") VALUES (2, 'Backup_20251106_015221', 'full', 'in_progress', NULL, NULL, '2025-11-06T01:52:21.458904+06:00', NULL, NULL, '', 1);

-- Table: Login_profile
DROP TABLE IF EXISTS Login_profile CASCADE;
CREATE TABLE Login_profile (
    id bigint NOT NULL,
    full_name character varying NOT NULL,
    phone character varying NOT NULL,
    email character varying NOT NULL,
    address text NOT NULL,
    profile_picture character varying NOT NULL,
    user_status character varying NOT NULL,
    user_id integer NOT NULL
);

-- Table: Login_profile (1 rows)
INSERT INTO "Login_profile" ("id", "full_name", "phone", "email", "address", "profile_picture", "user_status", "user_id") VALUES (1, 'admin', '', 'admin@example.com', '', '', 'user', 1);

-- Table: Map_historicalmap
DROP TABLE IF EXISTS Map_historicalmap CASCADE;
CREATE TABLE Map_historicalmap (
    id bigint NOT NULL,
    title character varying NOT NULL,
    status character varying NOT NULL,
    thumbnail text NOT NULL,
    publishing_date timestamp with time zone NOT NULL,
    views_count integer NOT NULL,
    history_id integer NOT NULL,
    history_date timestamp with time zone NOT NULL,
    history_change_reason character varying,
    history_type character varying NOT NULL,
    history_user_id integer,
    user_id integer
);

-- Table: Map_map
DROP TABLE IF EXISTS Map_map CASCADE;
CREATE TABLE Map_map (
    id bigint NOT NULL,
    title character varying NOT NULL,
    status character varying NOT NULL,
    thumbnail character varying NOT NULL,
    publishing_date timestamp with time zone NOT NULL,
    views_count integer NOT NULL,
    user_id integer NOT NULL
);

-- Table: Map_mapcolor
DROP TABLE IF EXISTS Map_mapcolor CASCADE;
CREATE TABLE Map_mapcolor (
    id bigint NOT NULL,
    color character varying NOT NULL,
    map_id bigint NOT NULL
);

-- Table: Map_mapfile
DROP TABLE IF EXISTS Map_mapfile CASCADE;
CREATE TABLE Map_mapfile (
    id bigint NOT NULL,
    file character varying NOT NULL,
    map_id bigint NOT NULL
);

-- Table: auth_group
DROP TABLE IF EXISTS auth_group CASCADE;
CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying NOT NULL
);

-- Table: auth_group_permissions
DROP TABLE IF EXISTS auth_group_permissions CASCADE;
CREATE TABLE auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);

-- Table: auth_permission
DROP TABLE IF EXISTS auth_permission CASCADE;
CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying NOT NULL
);

-- Table: auth_permission (48 rows)
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (1, 'Can add log entry', 1, 'add_logentry');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (2, 'Can change log entry', 1, 'change_logentry');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (3, 'Can delete log entry', 1, 'delete_logentry');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (4, 'Can view log entry', 1, 'view_logentry');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (5, 'Can add permission', 2, 'add_permission');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (6, 'Can change permission', 2, 'change_permission');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (7, 'Can delete permission', 2, 'delete_permission');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (8, 'Can view permission', 2, 'view_permission');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (9, 'Can add group', 3, 'add_group');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (10, 'Can change group', 3, 'change_group');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (11, 'Can delete group', 3, 'delete_group');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (12, 'Can view group', 3, 'view_group');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (13, 'Can add user', 4, 'add_user');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (14, 'Can change user', 4, 'change_user');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (15, 'Can delete user', 4, 'delete_user');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (16, 'Can view user', 4, 'view_user');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (17, 'Can add content type', 5, 'add_contenttype');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (18, 'Can change content type', 5, 'change_contenttype');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (19, 'Can delete content type', 5, 'delete_contenttype');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (20, 'Can view content type', 5, 'view_contenttype');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (21, 'Can add session', 6, 'add_session');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (22, 'Can change session', 6, 'change_session');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (23, 'Can delete session', 6, 'delete_session');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (24, 'Can view session', 6, 'view_session');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (25, 'Can add map', 7, 'add_map');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (26, 'Can change map', 7, 'change_map');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (27, 'Can delete map', 7, 'delete_map');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (28, 'Can view map', 7, 'view_map');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (29, 'Can add Map File', 8, 'add_mapfile');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (30, 'Can change Map File', 8, 'change_mapfile');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (31, 'Can delete Map File', 8, 'delete_mapfile');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (32, 'Can view Map File', 8, 'view_mapfile');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (33, 'Can add historical map', 9, 'add_historicalmap');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (34, 'Can change historical map', 9, 'change_historicalmap');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (35, 'Can delete historical map', 9, 'delete_historicalmap');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (36, 'Can view historical map', 9, 'view_historicalmap');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (37, 'Can add Map Color', 10, 'add_mapcolor');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (38, 'Can change Map Color', 10, 'change_mapcolor');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (39, 'Can delete Map Color', 10, 'delete_mapcolor');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (40, 'Can view Map Color', 10, 'view_mapcolor');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (41, 'Can add profile', 11, 'add_profile');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (42, 'Can change profile', 11, 'change_profile');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (43, 'Can delete profile', 11, 'delete_profile');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (44, 'Can view profile', 11, 'view_profile');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (45, 'Can add System Backup', 12, 'add_backup');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (46, 'Can change System Backup', 12, 'change_backup');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (47, 'Can delete System Backup', 12, 'delete_backup');
INSERT INTO "auth_permission" ("id", "name", "content_type_id", "codename") VALUES (48, 'Can view System Backup', 12, 'view_backup');

-- Table: auth_user
DROP TABLE IF EXISTS auth_user CASCADE;
CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    email character varying NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);

-- Table: auth_user (1 rows)
INSERT INTO "auth_user" ("id", "password", "last_login", "is_superuser", "username", "first_name", "last_name", "email", "is_staff", "is_active", "date_joined") VALUES (1, 'pbkdf2_sha256$600000$NOgHhpyv8VDLltd4z4rMCy$8MiFrv85UtTEmS5Mf5Yf5PgWElNsbo5UcMLW/WrfnkA=', '2025-11-06T01:52:00.082840+06:00', True, 'admin', '', '', 'admin@example.com', True, True, '2025-11-06T01:44:42.565433+06:00');

-- Table: auth_user_groups
DROP TABLE IF EXISTS auth_user_groups CASCADE;
CREATE TABLE auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);

-- Table: auth_user_user_permissions
DROP TABLE IF EXISTS auth_user_user_permissions CASCADE;
CREATE TABLE auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);

-- Table: django_admin_log
DROP TABLE IF EXISTS django_admin_log CASCADE;
CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL
);

-- Table: django_content_type
DROP TABLE IF EXISTS django_content_type CASCADE;
CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying NOT NULL,
    model character varying NOT NULL
);

-- Table: django_content_type (12 rows)
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (1, 'admin', 'logentry');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (2, 'auth', 'permission');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (3, 'auth', 'group');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (4, 'auth', 'user');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (5, 'contenttypes', 'contenttype');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (6, 'sessions', 'session');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (7, 'Map', 'map');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (8, 'Map', 'mapfile');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (9, 'Map', 'historicalmap');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (10, 'Map', 'mapcolor');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (11, 'Login', 'profile');
INSERT INTO "django_content_type" ("id", "app_label", "model") VALUES (12, 'Login', 'backup');

-- Table: django_migrations
DROP TABLE IF EXISTS django_migrations CASCADE;
CREATE TABLE django_migrations (
    id bigint NOT NULL,
    app character varying NOT NULL,
    name character varying NOT NULL,
    applied timestamp with time zone NOT NULL
);

-- Table: django_migrations (36 rows)
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (1, 'contenttypes', '0001_initial', '2025-11-06T01:42:58.383735+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (2, 'auth', '0001_initial', '2025-11-06T01:42:58.445491+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (3, 'Login', '0001_initial', '2025-11-06T01:42:58.462541+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (4, 'Login', '0002_alter_profile_user_status', '2025-11-06T01:42:58.471092+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (5, 'Login', '0003_alter_profile_profile_picture', '2025-11-06T01:42:58.477100+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (6, 'Login', '0004_backup', '2025-11-06T01:42:58.492663+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (7, 'Map', '0001_initial', '2025-11-06T01:42:58.519248+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (8, 'Map', '0002_alter_map_status', '2025-11-06T01:42:58.527376+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (9, 'Map', '0003_alter_map_thumbnail', '2025-11-06T01:42:58.537942+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (10, 'Map', '0004_historicalmap', '2025-11-06T01:42:58.559264+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (11, 'Map', '0005_notification', '2025-11-06T01:42:58.581630+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (12, 'Map', '0006_remove_notification_user_notification_recipient', '2025-11-06T01:42:58.612761+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (13, 'Map', '0007_alter_notification_recipient', '2025-11-06T01:42:58.627294+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (14, 'Map', '0008_delete_notification', '2025-11-06T01:42:58.631806+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (15, 'Map', '0009_mapcolor', '2025-11-06T01:42:58.652951+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (16, 'Map', '0010_alter_mapcolor_color', '2025-11-06T01:42:58.658955+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (17, 'Map', '0011_alter_mapcolor_color', '2025-11-06T01:42:58.665096+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (18, 'Map', '0012_alter_mapcolor_color', '2025-11-06T01:42:58.671119+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (19, 'Map', '0013_alter_map_options', '2025-11-06T01:42:58.680634+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (20, 'Map', '0014_alter_map_options', '2025-11-06T01:42:58.689143+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (21, 'admin', '0001_initial', '2025-11-06T01:42:58.805803+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (22, 'admin', '0002_logentry_remove_auto_add', '2025-11-06T01:42:58.818874+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (23, 'admin', '0003_logentry_add_action_flag_choices', '2025-11-06T01:42:58.829324+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (24, 'contenttypes', '0002_remove_content_type_name', '2025-11-06T01:42:58.848301+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (25, 'auth', '0002_alter_permission_name_max_length', '2025-11-06T01:42:58.860999+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (26, 'auth', '0003_alter_user_email_max_length', '2025-11-06T01:42:58.871519+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (27, 'auth', '0004_alter_user_username_opts', '2025-11-06T01:42:58.883075+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (28, 'auth', '0005_alter_user_last_login_null', '2025-11-06T01:42:58.935366+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (29, 'auth', '0006_require_contenttypes_0002', '2025-11-06T01:42:58.937368+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (30, 'auth', '0007_alter_validators_add_error_messages', '2025-11-06T01:42:58.945925+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (31, 'auth', '0008_alter_user_username_max_length', '2025-11-06T01:42:58.957944+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (32, 'auth', '0009_alter_user_last_name_max_length', '2025-11-06T01:42:58.969058+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (33, 'auth', '0010_alter_group_name_max_length', '2025-11-06T01:42:58.981525+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (34, 'auth', '0011_update_proxy_permissions', '2025-11-06T01:42:58.992059+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (35, 'auth', '0012_alter_user_first_name_max_length', '2025-11-06T01:42:59.001655+06:00');
INSERT INTO "django_migrations" ("id", "app", "name", "applied") VALUES (36, 'sessions', '0001_initial', '2025-11-06T01:42:59.011264+06:00');

-- Table: django_session
DROP TABLE IF EXISTS django_session CASCADE;
CREATE TABLE django_session (
    session_key character varying NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);

-- Table: django_session (1 rows)
INSERT INTO "django_session" ("session_key", "session_data", "expire_date") VALUES ('5xwmioptwxwg88wnkb40t5q9cuwzdihz', '.eJxVjD0PgjAYhP9LZ0No6aejCZvGyZlc27eWCCUBmYz_XUwYdLznnrsX67A-c7cuNHd9ZEfG2eGXeYQHlW9xnu59qfa8VO2IfrjOt00qGOkyRRpOu_z3kLHkbQ4ljAACKam5VCryZJ2zOsGQdzY2Eh6urkUAT45k9KGpNW-Sd9oYC_b-ACddOHo:1vGjY0:YLQh3TWQIei659WQbLHVgEp70GIJZOhphGwbTqH3Wn0', '2025-11-20T01:52:00.087843+06:00');

